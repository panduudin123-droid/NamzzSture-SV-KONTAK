# NAMZZ Save Kontak v2.0

Project Android Studio (Kotlin) dengan UI premium navy/biru.

## Fitur
- Import file CSV dan VCF melalui Android Storage Access Framework (pengguna memilih file).
- Pratinjau jumlah kontak dan beberapa contoh sebelum tindakan.
- Deteksi duplikat dalam file dan nomor yang sudah ada di kontak perangkat.
- Simpan banyak kontak setelah konfirmasi eksplisit dan izin WRITE_CONTACTS.
- Riwayat penyimpanan lokal (maksimal 20 baris ditampilkan).
- Backup/restore kontak dan riwayat aplikasi dalam JSON melalui pemilih file Android; restore menampilkan konfirmasi dan melewati duplikat.
- Tidak meminta akses internet dan tidak mengunggah data.

## Format CSV
Gunakan dua kolom: `name,phone` atau `nama,nomor`.
Contoh:
```csv
name,phone
Namzz,+628123456789
Contoh Kontak,+628987654321
```
Nama dengan koma boleh diapit tanda kutip.

## Build APK
1. Ekstrak ZIP.
2. Buka folder project di Android Studio.
3. Gunakan JDK 17 dan tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Backup lengkap mencakup nama dan nomor kontak yang tersedia di buku alamat perangkat serta riwayat aplikasi. File backup berisi data pribadi: simpan di lokasi aman dan jangan bagikan.
- CSV/VCF yang diimpor hanya dibaca setelah pengguna memilih file. Simpan hanya kontak yang kamu berhak simpan.
- Aplikasi tidak mengakses WhatsApp, tidak mengambil anggota grup, dan tidak melakukan scraping nomor.
- Uji di perangkat/emulator sebelum distribusi. Versi ini adalah source project; belum merupakan APK yang ditandatangani untuk Play Store.
