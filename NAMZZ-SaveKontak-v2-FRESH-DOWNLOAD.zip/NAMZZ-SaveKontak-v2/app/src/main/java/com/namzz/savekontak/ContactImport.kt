package com.namzz.savekontak

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import java.io.BufferedReader
import java.io.InputStreamReader

object ContactImport {
    fun read(context: Context, uri: Uri): List<ContactRecord> {
        val text = context.contentResolver.openInputStream(uri)?.use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
        } ?: return emptyList()
        val lower = uri.lastPathSegment?.lowercase().orEmpty()
        return if (lower.endsWith(".vcf") || text.contains("BEGIN:VCARD", true)) {
            parseVcf(text)
        } else {
            parseCsv(text)
        }.filter { it.name.isNotBlank() && it.phone.filter(Char::isDigit).length >= 8 }
            .distinctBy { it.normalizedPhone() }
    }

    // CSV format: name,phone. First row may be a header.
    private fun parseCsv(text: String): List<ContactRecord> {
        val rows = text.lineSequence().filter { it.isNotBlank() }.map(::splitCsvLine).toList()
        if (rows.isEmpty()) return emptyList()
        val first = rows.first().joinToString(" ").lowercase()
        val start = if ("name" in first || "nama" in first || "phone" in first || "nomor" in first) 1 else 0
        return rows.drop(start).mapNotNull { row ->
            if (row.size < 2) null else ContactRecord(row[0].trim(), row[1].trim())
        }
    }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { result.add(current.toString()); current.setLength(0) }
                else -> current.append(c)
            }
            i++
        }
        result.add(current.toString())
        return result
    }

    private fun parseVcf(text: String): List<ContactRecord> {
        val unfolded = text.replace("\r\n ", "").replace("\n ", "")
        val cards = unfolded.split(Regex("(?i)END:VCARD"))
        return cards.mapNotNull { card ->
            if (!card.contains("BEGIN:VCARD", true)) return@mapNotNull null
            val name = card.lineSequence().firstOrNull {
                it.startsWith("FN:", true) || it.startsWith("N:", true)
            }?.substringAfter(':')?.replace(';', ' ')?.trim().orEmpty()
            val phone = card.lineSequence().firstOrNull {
                it.startsWith("TEL", true) && it.contains(':')
            }?.substringAfter(':')?.trim().orEmpty()
            if (name.isBlank() || phone.isBlank()) null else ContactRecord(name, phone)
        }
    }
}

object ContactWriter {
    fun existingPhones(context: Context): Set<String> {
        val result = mutableSetOf<String>()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        cursor?.use {
            val index = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                if (index >= 0) result.add(it.getString(index).orEmpty().filter(Char::isDigit).trimStart('0'))
            }
        }
        return result
    }

    fun save(context: Context, records: List<ContactRecord>): Int {
        val ops = ArrayList<android.content.ContentProviderOperation>()
        records.forEach { record ->
            val rawInsert = ops.size
            ops.add(android.content.ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
            ops.add(android.content.ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawInsert)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, record.name).build())
            ops.add(android.content.ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawInsert)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, record.phone)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build())
        }
        if (ops.isNotEmpty()) context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
        return records.size
    }
}
