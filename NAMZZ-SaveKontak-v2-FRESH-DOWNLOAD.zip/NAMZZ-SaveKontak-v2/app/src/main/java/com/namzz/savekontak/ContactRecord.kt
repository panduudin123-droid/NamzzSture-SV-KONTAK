package com.namzz.savekontak

data class ContactRecord(
    val name: String,
    val phone: String
) {
    fun normalizedPhone(): String = phone.filter { it.isDigit() }.trimStart('0')
}
