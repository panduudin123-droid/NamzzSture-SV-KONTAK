package com.namzz.savekontak

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val blue = Color.rgb(36, 167, 255)
    private val navy = Color.rgb(7, 20, 38)
    private val panel = Color.rgb(17, 39, 66)
    private val white = Color.WHITE
    private val prefs by lazy { getSharedPreferences("namzz_local", MODE_PRIVATE) }
    private val imported = mutableListOf<ContactRecord>()
    private var pendingSave: List<ContactRecord> = emptyList()
    private lateinit var status: TextView
    private lateinit var preview: TextView
    private lateinit var history: TextView

    companion object {
        private const val PICK_FILE = 100
        private const val CREATE_BACKUP = 101
        private const val RESTORE_BACKUP = 102
        private const val WRITE_PERMISSION = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(navy)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        val header = TextView(this).apply {
            text = "NAMZZ  /  SAVE KONTAK"
            textSize = 22f; setTextColor(white); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(header, match())
        val sub = TextView(this).apply {
            text = "CONTACT MANAGER  •  VERSION 2.0"
            textSize = 11f; setTextColor(blue); gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        content.addView(sub, match())

        content.addView(section("IMPORT KONTAK"))
        content.addView(body("Pilih file CSV (kolom nama, nomor) atau VCF. Data diproses lokal di perangkat."))
        content.addView(actionButton("PILIH FILE CSV / VCF") { pickFile() }, top(10))

        preview = TextView(this).apply {
            text = "Belum ada file yang dipilih."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
        }
        content.addView(preview, top(10))

        content.addView(actionButton("CEK DUPLIKAT & SIMPAN KONTAK") { prepareSave() }, top(12))
        content.addView(section("RIWAYAT PENYIMPANAN"), top(22))
        history = TextView(this).apply {
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
        }
        content.addView(history, top(8))
        content.addView(section("BACKUP & RESTORE"), top(22))
        content.addView(body("Backup menyimpan riwayat aplikasi dalam file JSON. File kontak CSV/VCF tetap berada di lokasi yang kamu pilih."))
        content.addView(actionButton("BUAT BACKUP RIWAYAT") { createBackup() }, top(10))
        content.addView(actionButton("RESTORE BACKUP RIWAYAT") { restoreBackup() }, top(8))
        content.addView(body("Keamanan: aplikasi tidak memakai internet dan tidak mengunggah kontak. Periksa file dan izin sebelum menyimpan."), top(18))
        content.addView(TextView(this).apply {
            text = "NAMZZ STURE  •  PRIVATE BY DESIGN"
            textSize = 10f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setPadding(0, 24, 0, 8)
        }, match())

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHistory()
    }

    private fun section(text: String, params: LinearLayout.LayoutParams = match()) =
        TextView(this).apply {
            this.text = text; textSize = 14f; setTextColor(blue)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(2, 12, 2, 6)
        }.also { it.layoutParams = params }

    private fun body(text: String, params: LinearLayout.LayoutParams = match()) =
        TextView(this).apply {
            this.text = text; textSize = 12f; setTextColor(Color.LTGRAY)
            setPadding(2, 4, 2, 4)
        }.also { it.layoutParams = params }

    private fun actionButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f
            setTextColor(white); setBackgroundColor(Color.rgb(16, 103, 171))
            setOnClickListener { action() }
        }

    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun top(dp: Int) = match().apply { topMargin = (dp * resources.displayMetrics.density).toInt() }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/vcard", "text/x-vcard", "text/plain", "application/octet-stream"))
        }
        startActivityForResult(intent, PICK_FILE)
    }

    private fun prepareSave() {
        if (imported.isEmpty()) { message("Pilih file CSV atau VCF terlebih dahulu."); return }
        if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS), WRITE_PERMISSION)
            return
        }
        val existing = ContactWriter.existingPhones(this)
        val seen = mutableSetOf<String>()
        val unique = imported.filter { record ->
            val key = record.normalizedPhone()
            key.isNotBlank() && key !in existing && seen.add(key)
        }
        val duplicates = imported.size - unique.size
        if (unique.isEmpty()) { message("Tidak ada kontak baru. $duplicates nomor duplikat / sudah tersimpan."); return }
        AlertDialog.Builder(this)
            .setTitle("Konfirmasi penyimpanan")
            .setMessage("${unique.size} kontak baru akan disimpan.\n$duplicates nomor duplikat / sudah ada akan dilewati.\n\nLanjutkan? Pastikan kamu memiliki izin untuk menyimpan nomor ini.")
            .setNegativeButton("BATAL", null)
            .setPositiveButton("SIMPAN") { _, _ ->
                try {
                    val count = ContactWriter.save(this, unique)
                    addHistory(count, "Import file")
                    imported.clear()
                    preview.text = "Selesai: $count kontak tersimpan."
                    message("$count kontak berhasil disimpan.")
                } catch (e: Exception) {
                    message("Gagal menyimpan kontak: ${e.localizedMessage ?: "kesalahan tidak diketahui"}")
                }
            }.show()
    }

    private fun addHistory(count: Int, source: String) {
        val list = readHistory()
        list.put(JSONObject().put("time", System.currentTimeMillis()).put("count", count).put("source", source))
        prefs.edit().putString("history", list.toString()).apply()
        refreshHistory()
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }

    private fun refreshHistory() {
        val list = readHistory()
        if (list.length() == 0) { history.text = "Belum ada aktivitas."; return }
        val fmt = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
        history.text = (0 until list.length()).mapNotNull { i ->
            val item = list.optJSONObject(i) ?: return@mapNotNull null
            "• ${fmt.format(Date(item.optLong("time")))} — ${item.optInt("count")} kontak (${item.optString("source")})"
        }.reversed().take(20).joinToString("\n")
    }

    private fun createBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "namzz-savekontak-backup.json")
        }
        startActivityForResult(intent, CREATE_BACKUP)
    }

    private fun restoreBackup() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
        }
        startActivityForResult(intent, RESTORE_BACKUP)
    }

    private fun writeBackup(uri: Uri) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingBackupUri = uri
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), WRITE_PERMISSION + 1)
            return
        }
        val data = JSONObject()
            .put("app", "NAMZZ Save Kontak")
            .put("version", 2)
            .put("history", readHistory())
            .put("contacts", exportContacts())
        contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(data.toString(2)) }
        message("Backup kontak dan riwayat berhasil dibuat.")
    }

    private fun readBackup(uri: Uri) {
        val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: throw IllegalStateException("File tidak dapat dibaca")
        val obj = JSONObject(raw)
        require(obj.optString("app") == "NAMZZ Save Kontak") { "File bukan backup NAMZZ." }
        val restored = obj.optJSONArray("history") ?: JSONArray()
        val contacts = obj.optJSONArray("contacts") ?: JSONArray()
        val records = (0 until contacts.length()).mapNotNull { i ->
            val item = contacts.optJSONObject(i) ?: return@mapNotNull null
            val name = item.optString("name").trim()
            val phone = item.optString("phone").trim()
            if (name.isBlank() || phone.filter(Char::isDigit).length < 8) null else ContactRecord(name, phone)
        }
        prefs.edit().putString("history", restored.toString()).apply()
        refreshHistory()
        if (records.isNotEmpty()) {
            pendingRestore = records
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS), WRITE_PERMISSION + 2)
            } else confirmRestore()
        } else message("Riwayat berhasil dipulihkan. Tidak ada kontak dalam backup.")
    }

    private var pendingBackupUri: Uri? = null
    private var pendingRestore: List<ContactRecord> = emptyList()

    private fun exportContacts(): JSONArray {
        val array = JSONArray()
        val cursor = contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        cursor?.use {
            val nameIndex = it.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = it.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val name = if (nameIndex >= 0) it.getString(nameIndex).orEmpty() else ""
                val phone = if (phoneIndex >= 0) it.getString(phoneIndex).orEmpty() else ""
                if (name.isNotBlank() && phone.isNotBlank()) array.put(JSONObject().put("name", name).put("phone", phone))
            }
        }
        return array
    }

    private fun confirmRestore() {
        val existing = ContactWriter.existingPhones(this)
        val unique = pendingRestore.distinctBy { it.normalizedPhone() }.filter { it.normalizedPhone() !in existing }
        val skipped = pendingRestore.size - unique.size
        AlertDialog.Builder(this).setTitle("Pulihkan kontak?")
            .setMessage("${unique.size} kontak baru akan ditambahkan. $skipped duplikat akan dilewati. Lanjutkan?")
            .setNegativeButton("BATAL", null)
            .setPositiveButton("PULIHKAN") { _, _ ->
                try {
                    if (unique.isNotEmpty()) ContactWriter.save(this, unique)
                    addHistory(unique.size, "Restore backup")
                    message("${unique.size} kontak dipulihkan.")
                    pendingRestore = emptyList()
                } catch (e: Exception) { message("Restore gagal: ${e.localizedMessage}") }
            }.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            when (requestCode) {
                PICK_FILE -> {
                    imported.clear()
                    imported.addAll(ContactImport.read(this, uri))
                    preview.text = "Ditemukan ${imported.size} kontak valid.\nContoh:\n" +
                        imported.take(5).joinToString("\n") { "${it.name} — ${it.phone}" }
                    if (imported.isEmpty()) message("Tidak menemukan data kontak. Pastikan CSV memiliki kolom nama,nomor atau file VCF valid.")
                }
                CREATE_BACKUP -> writeBackup(uri)
                RESTORE_BACKUP -> readBackup(uri)
            }
        } catch (e: Exception) { message("Tidak dapat memproses file: ${e.localizedMessage}") }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == WRITE_PERMISSION) {
            if (grantResults.size == 2 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) prepareSave()
            else message("Izin kontak ditolak. Aktifkan izin Kontak di pengaturan aplikasi jika ingin menyimpan.")
        } else if (requestCode == WRITE_PERMISSION + 1) {
            val uri = pendingBackupUri
            pendingBackupUri = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && uri != null) {
                try {
                    val data = JSONObject().put("app", "NAMZZ Save Kontak").put("version", 2)
                        .put("history", readHistory()).put("contacts", exportContacts())
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(data.toString(2)) }
                    message("Backup kontak dan riwayat berhasil dibuat.")
                } catch (e: Exception) { message("Backup gagal: ${e.localizedMessage}") }
            } else message("Izin baca kontak diperlukan untuk membuat backup lengkap.")
        } else if (requestCode == WRITE_PERMISSION + 2) {
            if (grantResults.size == 2 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) confirmRestore()
            else message("Izin kontak diperlukan untuk memulihkan kontak.")
        }
    }

    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
